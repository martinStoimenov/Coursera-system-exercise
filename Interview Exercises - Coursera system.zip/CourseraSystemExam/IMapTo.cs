﻿namespace CourseraSystemExam
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapTo<T>
    {
    }
}
