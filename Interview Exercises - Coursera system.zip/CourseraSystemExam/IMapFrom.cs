﻿namespace CourseraSystemExam
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapFrom<T>
    {
    }
}
